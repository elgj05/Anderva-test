module.exports = {
  extends: '@loopback/eslint-config',

  rules: {
    '@typescript-eslint/no-explicit-any': 0,
  },
};
