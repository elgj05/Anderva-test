// ** Router Import
import Router from './router/Router'

const App = props => <Router />

export default App
