const icons = {
  home: require('./home.png'),
  learn: require('./learn.png'),
  events: require('./events.png'),
  menu: require('./menu.png'),
  search: require('./search.png'),
  back: require('./back.png'),
  call: require('./call.png'),
  play: require('./play.png'),
  time: require('./time.png'),
  calendar: require('./calendar.png'),
  couponBackground: require('./coupon-background.png'),
};

export default icons;
